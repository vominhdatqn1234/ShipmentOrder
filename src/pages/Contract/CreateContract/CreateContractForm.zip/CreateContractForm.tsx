import React, { useEffect, useRef, useState } from "react";
import {
  Button,
  Form as FormAntDeisgn,
  Input,
  message,
  Select,
  Upload,
  InputNumber,
  Switch,
  Space,
  Typography,
  Badge,
  DatePicker,
  Card,
  Checkbox,
} from "antd";
import type { FormInstance } from "antd/es/form";
import { useForm, useWatch } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import type { SelectProps, UploadProps } from "antd";
import {
  InboxOutlined,
  EyeInvisibleOutlined,
  EyeTwoTone,
} from "@ant-design/icons";
import { capitalize, find, isEmpty, map, reduce } from "lodash";
import { FormItem } from "../../../components/Form";
import { RcFile } from "antd/es/upload";
import { firestore, storage } from "../../../lib/firebase";
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { collection } from "firebase/firestore";
import { useFirestoreCollectionMutation } from "@react-query-firebase/firestore";
import { v4 as uuidv4 } from "uuid";
import {
  StatusColorType,
  formatCurrency,
  getStatusColor,
  isVietnamesePhoneNumber,
  regexPassword,
} from "../../../utils";
import dayjs, { Dayjs } from "dayjs";
import { ContractModel } from "../../../models";
import { useContract } from "../useContract";
import { useQueryClient } from "react-query";
import Editor from "../../../components/Editor";
import Viewer from "../../../components/Editor/Viewer";
import { useContractType } from "../ContractTypeList/useContractType";
import { useServicesArising } from "../ServicesArisingList/useServicesArising";
import { cn } from "../../../lib/cs";
import { useUser } from "../../../store/useUser";
import { PrintContract } from "../../../components/ComponentToPrint/PrintContract";

const { Dragger } = Upload;

const currentDate = dayjs();
const dateFormat = "DD-MM-YYYY";

const defaultValues = {
  contractType: undefined,
  userName: "",
  status: "",
  phone: "",
  address: "",
  discount: "",
  firstCheckDeposit: false,
  servicesArisingPrice: "",
  firstDepositPrice: "",
  firstDepositPriceDate: "",
  secondCheckDeposit: false,
  secondDepositPrice: "",
  secondDepositPriceDate: "",
  createDate: currentDate as Dayjs,
  shootingDate: currentDate as Dayjs,
  dueDate: dayjs(currentDate.add(3, "day")),
  contractPrice: "",
  contractImage: [],
  notes: "",
};

const statusList = ["active", "complete"];

const schema = yup
  .object({
    contractType: yup.mixed().required("Vui lòng chọn loại hợp đồng"),
    status: yup.string().required("Vui lòng chọn trạng thái hợp đồng"),
    phone: yup
      .string()
      .required("Vui lòng nhập số điện thoại của bạn!")
      .test("phone", "Số điên thoại sai định dạng", (str, context) => {
        return isVietnamesePhoneNumber(str);
      }),
    createDate: yup.date().required("Chọn ngày ký hợp đồng"),
    shootingDate: yup.date(),
    // .required("Chọn ngày ký hợp đồng"),
    dueDate: yup.date(),
    // .min(
    //   currentDate,
    //   "Ngày hoàn thành hợp đồng lớn hơn hoặc bằng ngày hiện tại!"
    // ),
    address: yup.string().required("Vui lòng địa chỉ"),
    // contractImage: yup
    //   .mixed()
    //   .required("Vui lòng upload file hình ảnh")
    //   .test("fileEmpty", "Vui lòng upload file hình ảnh", (value: any) => {
    //     if (value?.length === 0) return false;
    //     return true;
    //   }),
  })
  .required();

export default function CreateContractForm() {
  const formRef = useRef<FormInstance>(null);
  const [form] = FormAntDeisgn.useForm();
  const [messageApi, contextHolder] = message.useMessage();
  const [loading, setLoading] = useState(false);
  const contractRef = collection(firestore, "contract");
  const [fileList, setFileList] = useState<any[]>([]);
  const mutation = useFirestoreCollectionMutation(contractRef);
  const [uploadedImageUrls, setUploadedImageUrls] = useState<any[]>([]);
  const { refetch } = useContract();
  const { data: contractTypeData } = useContractType();
  const { data: servicesArisingData } = useServicesArising();
  const queryClient = useQueryClient();
  const uuId = uuidv4();
  const { user } = useUser();
  const isAdmin = user?.permission === "Admin";
  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    getValues,
  } = useForm<any>({
    defaultValues,
    resolver: yupResolver(schema),
  });

  const handleUpload = async (info: any) => {
    if (info.file.status === "done") {
      setFileList((prev) => [
        ...prev,
        {
          id: uuidv4(),
          url: info.file.url,
          name: info.file.name,
          alt: info.file.name.substr(0, info.file.name.lastIndexOf(".")),
        },
      ]);
      setValue("contractImage", [
        ...fileList,
        {
          id: uuidv4(),
          url: info.file.url,
          name: info.file.name,
          alt: info.file.name.substr(0, info.file.name.lastIndexOf(".")),
        },
      ]);
      message.success(`${info.file.name} file uploaded successfully`);
    } else if (info.file.status === "error") {
      message.error(`${info.file.name} file upload failed.`);
    }
  };

  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    if (fileList.length > 0) {
      const matchingUrls = fileList?.reduce((result: any, image: any) => {
        if (newFileList.some((file: any) => image?.id?.includes(file?.id))) {
          result.push(image);
        }
        return result;
      }, []);
      setFileList(matchingUrls);
      setValue("contractImage", matchingUrls);
    }
  };

  const customRequest = async ({ file, onSuccess, onError }: any) => {
    try {
      // const storageRef = ref(storage, `/files/${file.name}`);

      // const uploadTask = uploadBytesResumable(storageRef, file);

      // uploadTask.on(
      //   "state_changed",
      //   (snapshot) => {
      //     const percent = Math.round(
      //       (snapshot.bytesTransferred / snapshot.totalBytes) * 100
      //     );

      //     // update progress
      //     // setPercent(percent);
      //   },
      //   (err) => console.log(err),
      //   () => {
      //     // download url
      //     getDownloadURL(uploadTask.snapshot.ref).then((url) => {
      //       onSuccess();
      //       handleUpload({
      //         file: {
      //           status: "done",
      //           name: file.name,
      //           url,
      //         },
      //       });
      //     });
      //   }
      // );
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e: any) => {
        const originalImage = new Image() as any;
        originalImage.src = e.target.result;

        originalImage.onload = () => {
          // Define your desired dimensions
          const maxWidth = 800;
          const maxHeight = 800;

          // Calculate the new dimensions while preserving the aspect ratio
          const aspectRatio = originalImage.width / originalImage.height;
          let newWidth, newHeight;
          if (
            originalImage.width > maxWidth ||
            originalImage.height > maxHeight
          ) {
            if (aspectRatio > 1) {
              newWidth = maxWidth;
              newHeight = maxWidth / aspectRatio;
            } else {
              newWidth = maxHeight * aspectRatio;
              newHeight = maxHeight;
            }
          } else {
            newWidth = originalImage.width;
            newHeight = originalImage.height;
          }

          // Create a canvas element to draw the resized image
          const canvas = document.createElement("canvas");
          const ctx = canvas.getContext("2d") as any;
          canvas.width = newWidth;
          canvas.height = newHeight;

          // Draw the resized image on the canvas
          ctx.drawImage(originalImage, 0, 0, newWidth, newHeight);

          // Convert the canvas to a Blob (image file)
          canvas.toBlob((blob: any) => {
            // Create a new File object from the Blob
            const resizedFile = new File([blob], file.name, {
              type: file.type,
            });
            const storageRef = ref(
              storage,
              `/manager-page/${resizedFile.name}`
            );
            const uploadTask = uploadBytesResumable(storageRef, resizedFile);

            uploadTask.on(
              "state_changed",
              (snapshot) => {
                const percent = Math.round(
                  (snapshot.bytesTransferred / snapshot.totalBytes) * 100
                );

                // update progress
                // setPercent(percent);
              },
              (err) => console.log(err),
              () => {
                // download url
                getDownloadURL(uploadTask.snapshot.ref).then((url) => {
                  onSuccess();
                  handleUpload({
                    file: {
                      status: "done",
                      name: resizedFile.name,
                      url,
                    },
                  });
                });
              }
            );
          }, file.type);
        };
      };
    } catch (error) {
      console.error("Error uploading file:", error);
      onError();
    }
  };
  const props: UploadProps = {
    name: "file",
    multiple: true,
    listType: "picture-card",
    // beforeUpload,
    fileList,
    customRequest,
    onChange: handleChange,
    onDrop(e) {
      console.log("Dropped files", e.dataTransfer.files);
    },
  };

  const servicesArisingValue = FormAntDeisgn.useWatch("servicesArising", form);
  const nameValue = FormAntDeisgn.useWatch("contractType", form);
  const contractPriceValue = FormAntDeisgn.useWatch("contractPrice", form);
  const servicesArisingPriceValue = FormAntDeisgn.useWatch(
    "servicesArisingPrice",
    form
  );
  const discountValue = FormAntDeisgn.useWatch("discount", form);
  const firstDepositPriceValue = FormAntDeisgn.useWatch(
    "firstDepositPrice",
    form
  );
  const secondDepositPriceValue = FormAntDeisgn.useWatch(
    "secondDepositPrice",
    form
  );
  const firstCheckDepositValue = FormAntDeisgn.useWatch(
    "firstCheckDeposit",
    form
  );
  const secondCheckDepositValue = FormAntDeisgn.useWatch(
    "secondCheckDeposit",
    form
  );

  const options: SelectProps["options"] = map(servicesArisingData, (data) => ({
    value: data.serviceName,
    label: data.serviceName,
  }));
  const contractTypeOptions: SelectProps["options"] = map(contractTypeData, (data) => ({
    value: data.contractName,
    label: data.contractName,
    price: data.contractPrice
  }))

  useEffect(() => {
    if (nameValue) {
      const contractTypePrice = reduce(nameValue, (sum: any, value) => {
        console.log('value', value)
        const findContractType = find(contractTypeData, {
          contractName: value,
        });
        if (findContractType) {
          return sum += +findContractType?.contractPrice 
        }
        return sum
      }, 0)
      console.log('contractTypePrice', contractTypePrice)
      // const contractTypeValuePrice = map(
      //   data?.contractType,
      //   (contractName) => {
      //     const findContractType = find(contractTypeData, {
      //       contractName,
      //     });
      //     if (findContractType) {
      //       return {
      //         name: contractName || "",
      //         price: findContractType?.contractPrice,
      //       };
      //     }
      //     return {
      //       name: contractName || "",
      //       price: `${0}`,
      //     };
      //   }
      // );
        form.setFieldValue(
          "contractPrice",
          `${+contractTypePrice}`
        );
        setValue("contractPrice", `${+contractTypePrice}`);
    }
    if (servicesArisingValue?.length > 0) {
      const totalArisingPrice = reduce(
        servicesArisingValue,
        (total: number, item: string) => {
          const foundItem = find(servicesArisingData, { serviceName: item });
          if (foundItem) {
            return total + +foundItem.servicePrice;
          }
          return total;
        },
        0
      );
      form.setFieldValue("servicesArisingPrice", `${totalArisingPrice}`);
      setValue("servicesArisingPrice", `${totalArisingPrice}`);
    }
  });

  useEffect(() => {
    form.setFieldValue("status", "active");
    setValue("status", "active");
  }, []);
  const totalPrice = `${
    +contractPriceValue +
    +servicesArisingPriceValue -
    (+discountValue + +firstDepositPriceValue + +secondDepositPriceValue)
  }`;
  return (
    <>
      {contextHolder}
      <div className="py-6">
        <PrintContract getValues={getValues} />
      </div>
      <FormAntDeisgn
        form={form}
        name="control-create-contract-ref"
        ref={formRef}
        layout="vertical"
        initialValues={defaultValues}
        onFinish={handleSubmit((data) => {
          const contractSevicesArisingPrice = map(
            data?.servicesArising,
            (service) => {
              const findContractType = find(servicesArisingData, {
                serviceName: service,
              });
              if (findContractType) {
                return {
                  name: service || "",
                  price: findContractType?.servicePrice,
                };
              }
              return {
                name: service || "",
                price: `${0}`,
              };
            }
          );
          const contractTypeValuePrice = map(
            data?.contractType,
            (contractName) => {
              const findContractType = find(contractTypeData, {
                contractName,
              });
              if (findContractType) {
                return {
                  name: contractName || "",
                  price: findContractType?.contractPrice,
                };
              }
              return {
                name: contractName || "",
                price: `${0}`,
              };
            }
          );
          const payload: ContractModel = {
            ...data,
            firstPaymentMethod: data?.firstPaymentMethod || "",
            secondPaymentMethod: data?.secondPaymentMethod || "",
            servicesArising: data?.servicesArising || [],
            contractTypeValuePrice,
            contractSevicesArisingPrice,
            contractPrice: data?.contractPrice || "",
            contractImage: fileList,
            shootingDate: data?.shootingDate?.toISOString?.() || "",
            createDate: data?.createDate?.toISOString?.() || "",
            dueDate: data?.dueDate?.toISOString?.() || "",
            secondDepositPriceDate:
              data?.secondDepositPriceDate?.toISOString?.() || "",
            firstDepositPriceDate:
              data?.firstDepositPriceDate?.toISOString?.() || "",
            notes: data?.notes ? [data?.notes] : [],
            // totalPrice: `${
            //   +contractPriceValue + +servicesArisingPriceValue - +discountValue
            // }`,
          };
          console.log("payload", payload);
          // mutation.mutate(payload);
          // queryClient.invalidateQueries("contract");
          // setTimeout(async () => await refetch(), 300);
          // setLoading(true);
          // messageApi.open({
          //   type: "success",
          //   content: "Tạo hợp đồng thành công!",
          //   duration: 5,
          // });
          // setLoading(false);
          // form.resetFields();
          // formRef.current?.resetFields();
          // reset();
          // setFileList([]);
        })}
      >
        <div className="grid grid-cols-1 xl:grid-cols-3 xl:gap-6">
          <FormItem control={control} name="contractType" label="Loại hợp đồng">
          <Select
              mode="multiple"
              allowClear
              showSearch
              style={{ width: "100%" }}
              placeholder="Chọn loại hợp đồng"
              options={contractTypeOptions}
            />
            {/* <Select showSearch>
              {contractTypeData.map((dt) => {
                return (
                  <Select.Option
                    key={`contract-type-${dt.id}`}
                    
                    value={dt?.contractName}
                  >
                    {dt?.contractName}
                  </Select.Option>
                );
              })}
            </Select> */}
          </FormItem>
          <FormItem
            control={control}
            name="servicesArising"
            label="Danh mục phát sinh"
          >
            <Select
              mode="multiple"
              allowClear
              showSearch
              style={{ width: "100%" }}
              placeholder="Chọn danh mục phát sinh"
              options={options}
            />
          </FormItem>
          <FormItem control={control} name="status" label="Trạng thái">
            <Select showSearch>
              {statusList.map((sts, index) => {
                return (
                  <Select.Option key={index} value={sts}>
                    <Badge
                      color={getStatusColor(
                        (`${sts}`.toLowerCase() as StatusColorType) || "pending"
                      )}
                      text={capitalize(sts)}
                    />
                  </Select.Option>
                );
              })}
            </Select>
          </FormItem>
        </div>
        <div className="grid grid-cols-1 xl:grid-cols-3 xl:gap-6">
          <FormItem control={control} name="userName" label="Tên khách hàng">
            <Input allowClear placeholder="Nhập tên khách hàng" />
          </FormItem>
          <FormItem control={control} name="phone" label="Số điện thoại">
            <Input allowClear placeholder="Nhập số điện thoại" />
          </FormItem>
          <FormItem control={control} name="address" label="Địa chỉ">
            <Input allowClear placeholder="Nhập địa chỉ" />
          </FormItem>
        </div>
        <div className="grid grid-cols-1 xl:grid-cols-3 xl:gap-6">
          <FormItem
            control={control}
            name="contractPrice"
            label="Giá hợp đồng"
            valuePropName="value"
          >
            <InputNumber
              disabled
              style={{ width: "100%" }}
              placeholder="Giá hợp đồng"
              formatter={(value) =>
                `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
              }
            />
          </FormItem>
          <div className={cn(!isAdmin && "hidden")}>
            <FormItem
              control={control}
              name="servicesArisingPrice"
              label="Giá mục phát sinh"
              valuePropName="value"
            >
              <InputNumber
                disabled
                style={{ width: "100%" }}
                placeholder="Giá mục phát sinh"
                formatter={(value) =>
                  `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                }
              />
            </FormItem>
          </div>
          <FormItem
            control={control}
            name="discount"
            label="Giá discount"
            valuePropName="value"
          >
            <InputNumber
              style={{ width: "100%" }}
              placeholder="Giá discount"
              formatter={(value) =>
                `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
              }
            />
          </FormItem>
        </div>
        <div className="pb-6">
          <Space>
            <span className="text-lg font-semibold text-gray-900">
              Thành tiền:
            </span>
            <span className="text-lg font-semibold text-blue-600">
              {formatCurrency(
                `${+contractPriceValue + +servicesArisingPriceValue}`
              )}
            </span>
          </Space>
        </div>
        <div className="pb-6">
          <Space>
            <span className="text-lg font-semibold text-gray-900">
              Thanh toán còn lại:
            </span>
            <span className="text-lg font-semibold text-blue-600">
              {formatCurrency(totalPrice)}
            </span>
          </Space>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 xl:gap-6">
          <FormItem
            control={control}
            name="createDate"
            label="Ngày ký hợp đồng"
          >
            <DatePicker
              format={dateFormat}
              placeholder="Vui lòng chọn ngày ký hợp đồng"
              style={{ width: "100%" }}
            />
          </FormItem>
          <FormItem control={control} name="shootingDate" label="Ngày bấm máy">
            <DatePicker
              format={dateFormat}
              placeholder="Vui lòng chọn ngày bấm máy"
              style={{ width: "100%" }}
            />
          </FormItem>
          <FormItem
            control={control}
            name="dueDate"
            label="Ngày hoàn thành hợp đồng"
          >
            <DatePicker
              format={dateFormat}
              placeholder="Vui lòng chọn ngày hoàn thành hợp đồng"
              style={{ width: "100%" }}
            />
          </FormItem>
        </div>
        {/* <div className="py-6">
          <FormItem
            control={control}
            name="contractImage"
            // valuePropName='fileList'
            label="Upload hình ảnh hợp đồng"
          >
            <Dragger {...props}>
              <p className="ant-upload-drag-icon">
                <InboxOutlined />
              </p>
              <p className="ant-upload-text">
                Nhấp hoặc kéo tệp vào khu vực này để tải lên
              </p>
              <p className="ant-upload-hint">
                Hỗ trợ tải lên một lần hoặc hàng loạt. Nghiêm cấm tải lên dữ
                liệu công ty hoặc các thông tin khác
              </p>
            </Dragger>
          </FormItem>
        </div> */}
        <div className="grid grid-cols-1 xl:grid-cols-2 xl:gap-6 pb-6">
          <Card
            size="small"
            title="Cọc lần 1"
            extra={
              <FormItem
                style={{ marginBottom: 0 }}
                control={control}
                name="firstCheckDeposit"
                valuePropName="checked"
              >
                <Checkbox />
              </FormItem>
            }
          >
            <div className="grid grid-cols-1 xl:grid-cols-2 xl:gap-6 pb-6">
              <FormItem
                control={control}
                name="firstDepositPrice"
                label="Tiền cọc lần 1"
              >
                <InputNumber
                  disabled={!firstCheckDepositValue}
                  style={{ width: "100%" }}
                  placeholder="Nhập tiền cọc lần 1"
                  formatter={(value) =>
                    `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                  }
                />
              </FormItem>
              <FormItem
                control={control}
                name="firstDepositPriceDate"
                label="Ngày cọc lần 1"
              >
                <DatePicker
                  disabled={!firstCheckDepositValue}
                  format={dateFormat}
                  placeholder="Vui lòng chọn ngày cọc lần 1"
                  style={{ width: "100%" }}
                />
              </FormItem>
              <FormItem
                control={control}
                name="firstPaymentMethod"
                label="Phương thức thanh toán"
              >
                <Select
                  style={{ width: 140 }}
                  disabled={!firstCheckDepositValue}
                  options={[
                    { value: "Chuyển khoản", label: "Chuyển khoản" },
                    { value: "Tiền mặt", label: "Tiền mặt" },
                  ]}
                />
              </FormItem>
            </div>
          </Card>
          <Card
            size="small"
            title="Cọc lần 2"
            extra={
              <FormItem
                style={{ marginBottom: 0 }}
                control={control}
                name="secondCheckDeposit"
                valuePropName="checked"
              >
                <Checkbox />
              </FormItem>
            }
          >
            <div className="grid grid-cols-1 xl:grid-cols-2 xl:gap-6 pb-6">
              <FormItem
                control={control}
                name="secondDepositPrice"
                label="Tiền cọc lần 2"
              >
                <InputNumber
                  disabled={!secondCheckDepositValue}
                  style={{ width: "100%" }}
                  placeholder="Nhập tiền cọc lần 2"
                  formatter={(value) =>
                    `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                  }
                />
              </FormItem>
              <FormItem
                control={control}
                name="secondDepositPriceDate"
                label="Ngày cọc lần 2"
              >
                <DatePicker
                  disabled={!secondCheckDepositValue}
                  format={dateFormat}
                  placeholder="Vui lòng chọn ngày cọc lần 2"
                  style={{ width: "100%" }}
                />
              </FormItem>
              <FormItem
                control={control}
                name="secondPaymentMethod"
                label="Phương thức thanh toán"
              >
                <Select
                  style={{ width: 140 }}
                  disabled={!secondCheckDepositValue}
                  options={[
                    { value: "Chuyển khoản", label: "Chuyển khoản" },
                    { value: "Tiền mặt", label: "Tiền mặt" },
                  ]}
                />
              </FormItem>
            </div>
          </Card>
        </div>

        <div className="pb-6">
          <FormItem control={control} name="notes" label="Ghi chú">
            <Editor />
          </FormItem>
        </div>
        {/* <Viewer value={`**anh yeu em**
        1. [13213123](13213123)2. **anh yeu em**`} /> */}
        <Button
          loading={loading}
          disabled={!isEmpty(errors)}
          type="primary"
          htmlType="submit"
          block
          size="large"
          className="mt-6"
        >
          Tạo hợp đồng
        </Button>
      </FormAntDeisgn>
    </>
  );
}
